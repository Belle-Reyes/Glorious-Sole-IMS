﻿namespace Dashboard_Menchero_Ursua
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label4 = new Label();
            progressBar1 = new ProgressBar();
            progressBar2 = new ProgressBar();
            progressBar3 = new ProgressBar();
            progressBar4 = new ProgressBar();
            progressBar5 = new ProgressBar();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.black;
            pictureBox1.Location = new Point(-7, -7);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(981, 56);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources._3;
            pictureBox2.Location = new Point(-7, 40);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(981, 79);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(0, 98);
            label1.Name = "label1";
            label1.Size = new Size(104, 25);
            label1.TabIndex = 3;
            label1.Text = "Dashboard";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(100, 151);
            label2.Name = "label2";
            label2.Size = new Size(175, 25);
            label2.TabIndex = 4;
            label2.Text = "Inventory Summary";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(451, 151);
            label3.Name = "label3";
            label3.Size = new Size(143, 25);
            label3.TabIndex = 5;
            label3.Text = "Inventory Value";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources._7;
            pictureBox3.Location = new Point(28, 193);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(317, 121);
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources._7;
            pictureBox4.Location = new Point(369, 193);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(317, 121);
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(766, 151);
            label4.Name = "label4";
            label4.Size = new Size(140, 25);
            label4.TabIndex = 8;
            label4.Text = "Product Details";
            // 
            // progressBar1
            // 
            progressBar1.BackColor = SystemColors.Control;
            progressBar1.Location = new Point(714, 193);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(224, 23);
            progressBar1.TabIndex = 9;
            progressBar1.Click += progressBar1_Click;
            // 
            // progressBar2
            // 
            progressBar2.BackColor = SystemColors.Control;
            progressBar2.Location = new Point(714, 231);
            progressBar2.Name = "progressBar2";
            progressBar2.Size = new Size(224, 23);
            progressBar2.TabIndex = 10;
            // 
            // progressBar3
            // 
            progressBar3.BackColor = SystemColors.Control;
            progressBar3.Location = new Point(714, 269);
            progressBar3.Name = "progressBar3";
            progressBar3.Size = new Size(224, 23);
            progressBar3.TabIndex = 11;
            // 
            // progressBar4
            // 
            progressBar4.BackColor = SystemColors.Control;
            progressBar4.Location = new Point(714, 307);
            progressBar4.Name = "progressBar4";
            progressBar4.Size = new Size(224, 23);
            progressBar4.TabIndex = 12;
            // 
            // progressBar5
            // 
            progressBar5.BackColor = SystemColors.Control;
            progressBar5.Location = new Point(714, 345);
            progressBar5.Name = "progressBar5";
            progressBar5.Size = new Size(224, 23);
            progressBar5.TabIndex = 13;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Image = Properties.Resources._7;
            label5.Location = new Point(122, 215);
            label5.Name = "label5";
            label5.Size = new Size(128, 17);
            label5.TabIndex = 14;
            label5.Text = "Number of products";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Image = Properties.Resources._7;
            label6.Location = new Point(56, 236);
            label6.Name = "label6";
            label6.Size = new Size(261, 45);
            label6.TabIndex = 15;
            label6.Text = "00,000 products";
            label6.TextAlign = ContentAlignment.TopCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Image = Properties.Resources._7;
            label7.Location = new Point(400, 236);
            label7.Name = "label7";
            label7.Size = new Size(261, 45);
            label7.TabIndex = 17;
            label7.Text = "00,000 products";
            label7.TextAlign = ContentAlignment.TopCenter;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Image = Properties.Resources._7;
            label8.Location = new Point(478, 215);
            label8.Name = "label8";
            label8.Size = new Size(92, 17);
            label8.TabIndex = 16;
            label8.Text = "Total products";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45.022625F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54.977375F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 215F));
            tableLayoutPanel1.Location = new Point(28, 360);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 49.1071434F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50.8928566F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 47F));
            tableLayoutPanel1.Size = new Size(658, 160);
            tableLayoutPanel1.TabIndex = 18;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(969, 532);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(progressBar5);
            Controls.Add(progressBar4);
            Controls.Add(progressBar3);
            Controls.Add(progressBar2);
            Controls.Add(progressBar1);
            Controls.Add(label4);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Dashboard";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label4;
        private ProgressBar progressBar1;
        private ProgressBar progressBar2;
        private ProgressBar progressBar3;
        private ProgressBar progressBar4;
        private ProgressBar progressBar5;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TableLayoutPanel tableLayoutPanel1;
    }
}
