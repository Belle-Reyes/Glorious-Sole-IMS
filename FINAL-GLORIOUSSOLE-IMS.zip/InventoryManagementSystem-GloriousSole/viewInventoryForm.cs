﻿using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class viewInventoryForm : Form
    {
        // Connection string for the local database
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\OneDrive_2024-12-10\GS_IMS Design PLEASE\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";

        public viewInventoryForm()
        {
            InitializeComponent(); // Initialize form components
            InitializeSortComboBox(); // Set up sorting options
            LoadData(); // Load inventory data
        }

        // Populate sorting options in the combo box
        private void InitializeSortComboBox()
        {
            cbSortBy.Items.AddRange(new string[] {
                "Recently Updated", "A-Z", "Z-A", "Price (Low to High)", "Price (High to Low)"
            });
            cbSortBy.SelectedIndex = 1; // Default sort order
        }

        // Load data from the database with optional sorting
        private void LoadData(string sortOrder = "A-Z")
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cm = new SqlCommand())
            {
                cm.Connection = con;

                try
                {
                    con.Open(); // Open connection
                    string query = @"SELECT Brand, Model, Size, Quantity, PricePerPiece, (Quantity * PricePerPiece) AS TotalPrice FROM Inventory";

                    // Append sorting order to the query
                    switch (sortOrder)
                    {
                        case "A-Z": query += " ORDER BY Brand ASC"; break;
                        case "Z-A": query += " ORDER BY Brand DESC"; break;
                        case "Price (Low to High)": query += " ORDER BY PricePerPiece ASC"; break;
                        case "Price (High to Low)": query += " ORDER BY PricePerPiece DESC"; break;
                        case "Recently Updated": query += " ORDER BY UpdatedAt DESC"; break;
                    }

                    cm.CommandText = query; // Set command text
                    SqlDataAdapter da = new SqlDataAdapter(cm);
                    DataTable dt = new DataTable();
                    da.Fill(dt); // Fill DataTable
                    dgvInventoryView.DataSource = dt; // Bind to DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message); // Show errors
                }
            }
        }

        // Navigate to the Dashboard
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboardForm d = new dashboardForm();
            this.Hide(); // Hide current form
            d.ShowDialog(); // Show dashboard
        }

        // Navigate to Update Inventory
        private void btnUpdateInventory_Click(object sender, EventArgs e)
        {
            updateInventoryForm ui = new updateInventoryForm();
            this.Hide(); // Hide current form
            ui.ShowDialog(); // Show update form
        }

        // Navigate to Invoice Logs
        private void btnInvoiceLogs_Click(object sender, EventArgs e)
        {
            invoiceLogsForm il = new invoiceLogsForm();
            this.Hide(); // Hide current form
            il.ShowDialog(); // Show invoice logs
        }

        // Navigate to Manage Account
        private void btnManageAccount_Click(object sender, EventArgs e)
        {
            manageAccountForm ma = new manageAccountForm();
            this.Hide(); // Hide current form
            ma.ShowDialog(); // Show manage account
        }

        // Reload data when sorting option changes
        private void cbSortBy_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string selectedSortOrder = cbSortBy.SelectedItem.ToString(); // Get selected sort order
            LoadData(selectedSortOrder); // Reload data
        }

        // Handle logout action
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to log out?",
                "Logout Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit(); // Close application
            }
        }
    }
}