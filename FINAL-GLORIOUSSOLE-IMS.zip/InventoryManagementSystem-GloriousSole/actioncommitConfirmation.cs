﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem_GloriousSole
{
    public partial class actioncommitConfirmation : Form
    {
        public Action<bool> OnActionConfirmed;
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\reyes\Downloads\OneDrive_2024-12-10\GS_IMS Design PLEASE\SQL InventoryManagementSystem-GloriousSole\GS_IMS.mdf"";Integrated Security=True;Connect Timeout=30";
        SqlConnection con;
        SqlCommand cm;
        SqlDataReader dr;
        public actioncommitConfirmation()
        {
            InitializeComponent();
            txtAdminPassword.PasswordChar = '*';
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            string password = txtAdminPassword.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cm = new SqlCommand("SELECT * FROM Users WHERE Role = 'Admin' AND PasswordHash = @Password", con))
                {
                    cm.Parameters.AddWithValue("@Password", password);
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            MessageBox.Show("Changes successful!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            OnActionConfirmed?.Invoke(true); // Notify that action is accepted
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Invalid password!", "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtAdminPassword.Clear();
                        }
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            OnActionConfirmed?.Invoke(false); // Notify that action is cancelled
            updateInventoryForm ui = new updateInventoryForm();
            this.Hide();
            ui.ShowDialog();
        }
    }
}
